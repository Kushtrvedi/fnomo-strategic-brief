# Follow-Up with Dr. Gopal Batni (Apollo Sage Hospital)

Additional Information: Follow up on the sent outreach and reopen the decision-validation angle with one concrete question tied to their last wrong financial or commercial decision. | [2026-05-03 Sunday planning rule] Sunday is planning-only; due date moved to 2026-05-04.
Client: Apollo Sage Hospital (../Clients/Apollo%20Sage%20Hospital%203548aa3cb995816686d3e4f0fa4c3f14.md)
Contact: Dr. Gopal Batni (../Contacts/Dr%20Gopal%20Batni%203548aa3cb99581eabcfce87c204afc4e.md)
Due date: May 4, 2026
Overdue: Yes
Priority: Medium
Stage Context: Contacted
Status: To Do
Type: Follow-Up