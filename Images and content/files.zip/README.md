# FNOMO Email Execution System

Automated NEPQ cold email pipeline:  
**Excel → Claude AI (email gen) → Zoho Mail API (scheduled send)**

---

## Architecture

```
main.py
├── Phase 0  — Zoho token health check
├── Phase 1  — lead_loader.py      → reads Excel, validates rows
├── Phase 2  — email_generator.py  → Claude generates unique NEPQ emails
├── Phase 3  — zoho_sender.py      → builds Zoho API payloads
├── Phase 4  — scheduler.py        → randomised 7–25 min delay slots
├── Phase 5  — zoho_sender.py      → validates + schedules each email
└── Phase 6  — report printed + JSON log saved
```

---

## One-Time Setup

### 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### 2 — Create a Zoho API app
1. Go to https://api-console.zoho.com/
2. Click **Add Client** → choose **Server-based Applications**
3. Set redirect URI to: `https://www.zoho.com`
4. Copy your **Client ID** and **Client Secret**

### 3 — Get your refresh token (one-time)
```bash
# Add Client ID + Secret to config.py first, then:
python zoho_oauth_setup.py
```
Follow the prompts. Paste the printed `refresh_token` and `account_id` into `config.py`.

### 4 — Add your Anthropic API key
Get it from: https://console.anthropic.com/  
Paste into `config.py` → `ANTHROPIC_API_KEY`

### 5 — Set your Excel path
```python
# config.py
EXCEL_PATH = r"D:\Antigravity\eigent\Downloads\fnomo\EXCEL\FNOMO_CA_AGGRESSIVE_SCRAPE_86500.xlsx"
```
The file needs columns for **email** and **name** (exact names are auto-detected).

---

## Running

```bash
# Dry run — no emails sent, full output shown
python main.py --dry-run

# Live run — emails scheduled in Zoho Mail
python main.py
```

---

## Scheduling Rules

| Rule | Value |
|------|-------|
| Working window | 10:00 AM – 6:00 PM |
| Delay between emails | 7–25 min (random) |
| Max emails per day | 25 |
| Pattern | No fixed interval — fully randomised |

Example slot sequence: `10:07 → 10:19 → 10:43 → 11:12 → 11:32 …`

---

## Output

After each run you get:
- **Console report** (status, slots used, issues)
- **JSON log file** (`fnomo_run_YYYYMMDD_HHMMSS.json`)

---

## Email Format (NEPQ)

Each email is **uniquely generated** per lead by Claude:

```
Subject: (max 5 words, curiosity-driven)

[Context observation]
[Decision gap]
[Thought-provoking question]
[Soft CTA]

---
Fnomo is institutional research infrastructure for educational purposes.
We do not provide investment advice, brokerage services, or performance guarantees.
All decisions remain with the user.
```

- 120–150 words per email  
- Plain text only  
- No template repetition across the batch

---

## File Structure

```
fnomo_emailer/
├── main.py                # Orchestrator
├── config.py              # All credentials + settings
├── lead_loader.py         # Phase 1 — Excel reader
├── email_generator.py     # Phase 2 — Claude NEPQ generator
├── scheduler.py           # Phase 4 — Time slot builder
├── zoho_sender.py         # Phase 3/5 — Zoho API + validation
├── zoho_oauth_setup.py    # One-time OAuth setup helper
├── requirements.txt
└── README.md
```
